package com.stockmarket.stockservice.repository;

import com.stockmarket.stockservice.entities.StockPriceDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StockRepository extends JpaRepository<StockPriceDetails, Long> {

    StockPriceDetails findByCompanyCode(String companyCode);
    void deleteByCompanyCode(String companyCode);
}