package com.stockmarket.stockservice.service;

import com.stockmarket.stockservice.VO.CompanyDetails;
import com.stockmarket.stockservice.VO.ResponseTemplateVO;
import com.stockmarket.stockservice.entities.StockPriceDetails;
import com.stockmarket.stockservice.pojo.StockDetailsPojo;
import com.stockmarket.stockservice.repository.StockRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class StockService {

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private RestTemplate restTemplate;

    public StockPriceDetails saveStock(StockPriceDetails stock) {
        return stockRepository.save(stock);
    }

    public StockPriceDetails findCompanyByCode(String companyCode) {
        return stockRepository.findByCompanyCode(companyCode);
    }

    public String deleteStockWithCompanyDetails(String companyCode){
        List<StockPriceDetails> stockDetailsListList=stockRepository.findAll();
        System.out.println("stockDetailsListList.size()"+":"+stockDetailsListList.size());
        for (int i=0;i<stockDetailsListList.size();i++) {
            if(stockDetailsListList.get(i).getCompanyCode().equals(companyCode)) {
                System.out.println("inside if condition stockDetailsListList.get(i).getCompanyCode()"+":"+stockDetailsListList.get(i).getCompanyCode());
                stockRepository.deleteById(stockDetailsListList.get(i).getStockId());
            }
        }
        return "Company and Stock Details deleted successfully for the companyCode :  " + companyCode;
    }

    public ResponseTemplateVO getStockWithCompanyDetails(String companyCode) {
        List<StockDetailsPojo> stockDetailList=new ArrayList<StockDetailsPojo>();
        log.info("Inside Service-Get Stock Details By Company Code");

        ResponseTemplateVO vo = new ResponseTemplateVO();
        CompanyDetails company= restTemplate.getForObject(
                "http://COMPANY-SERVICE/companies/companyDetails/" + companyCode,CompanyDetails.class);
        List<StockPriceDetails> allStockDetails= stockRepository.findAll();
        for (int i=0;i<allStockDetails.size();i++) {
            System.out.println("allStockDetails.get(i).getCompanyCode()"+":"+allStockDetails.get(i).getCompanyCode());
            if(allStockDetails.get(i).getCompanyCode().equals(companyCode)) {
                StockDetailsPojo stockPojo= new StockDetailsPojo();
                System.out.println("inside if condition stockDetails.get(i).getCompanyCode()"+":"+allStockDetails.get(i).getCompanyCode());
                stockPojo.setCompanyCode(allStockDetails.get(i).getCompanyCode());
                stockPojo.setPrice(allStockDetails.get(i).getPrice());
                stockPojo.setCreationDate(allStockDetails.get(i).getCreationDate());
                stockPojo.setStockId(allStockDetails.get(i).getStockId());
                System.out.println("stockID  :  "+allStockDetails.get(i).getStockId());
                stockPojo.setTime(allStockDetails.get(i).getTime());
                stockDetailList.add(stockPojo);
            }
        }

        vo.setCompany(company);
        vo.setStock(stockDetailList);

        return vo;
    }
}

