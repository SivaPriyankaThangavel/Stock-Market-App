package com.stockmarket.stockservice.VO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDetails {
    private String companyCode;
    private String companyName;
    private String companyCEO;
    private String companyTurnOver;
    private String companyWebsite;
    private String stockExchange;
    private Date creationDate = new Date();
}
