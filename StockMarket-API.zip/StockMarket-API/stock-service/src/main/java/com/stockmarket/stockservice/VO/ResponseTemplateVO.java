package com.stockmarket.stockservice.VO;

import com.stockmarket.stockservice.pojo.StockDetailsPojo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplateVO {
    private CompanyDetails company;
    private List<StockDetailsPojo> stock;
}
