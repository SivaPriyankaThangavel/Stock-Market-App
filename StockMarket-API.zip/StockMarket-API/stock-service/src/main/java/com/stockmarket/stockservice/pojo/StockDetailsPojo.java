package com.stockmarket.stockservice.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockDetailsPojo {
    private Long stockId;
    private String companyCode;
    private double price;
    private Date creationDate = new Date();
    private LocalTime time= LocalTime.now();
}
