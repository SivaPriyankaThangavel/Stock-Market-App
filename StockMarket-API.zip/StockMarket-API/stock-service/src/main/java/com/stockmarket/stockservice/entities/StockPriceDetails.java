package com.stockmarket.stockservice.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalTime;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockPriceDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long stockId;
    private String companyCode;
    private double price;
    private Date creationDate = new Date();
    private LocalTime time= LocalTime.now();
}

