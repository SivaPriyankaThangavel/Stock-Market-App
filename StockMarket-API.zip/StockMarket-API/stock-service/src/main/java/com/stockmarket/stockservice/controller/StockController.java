package com.stockmarket.stockservice.controller;

import com.stockmarket.stockservice.VO.ResponseTemplateVO;
import com.stockmarket.stockservice.entities.StockPriceDetails;
import com.stockmarket.stockservice.service.StockService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stocks")
@Slf4j
public class StockController {

    @Autowired
    private StockService stockService;

    @PostMapping("/")
    public StockPriceDetails addStock(@RequestBody StockPriceDetails stock) {
        log.info("Inside saveStock Method of StockController");
        return stockService.saveStock(stock);

    }

    @GetMapping("/stockInfo/{companyCode}")
    public ResponseTemplateVO getStockWithCompanyCode(@PathVariable String companyCode){
        log.info("Inside Controller-Get Stock Details by Company Code");
        return stockService.getStockWithCompanyDetails(companyCode);
    }

    @GetMapping("/{companyCode}")
    public StockPriceDetails findByCompanyCode(@PathVariable("companyCode") String companyCode) {
        StockPriceDetails stock = stockService.findCompanyByCode(companyCode);
        System.out.println("company code" + stock);
        return stock;
    }

    @DeleteMapping("/delete/{companyCode}")
    public String deleteStockWithCompanyCode(@PathVariable String companyCode){
        log.info("Inside Controller-delete Stock Details by Company Code");
        String message = stockService.deleteStockWithCompanyDetails(companyCode);
        return message+"---"+companyCode;
    }
}

