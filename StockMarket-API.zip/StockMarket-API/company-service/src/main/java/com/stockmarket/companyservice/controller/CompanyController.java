package com.stockmarket.companyservice.controller;

import com.stockmarket.companyservice.entities.CompanyDetails;
import com.stockmarket.companyservice.service.CompanyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/companies")
@Slf4j
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @PostMapping("/")
    public CompanyDetails saveCompany(@RequestBody CompanyDetails company) {
        log.info("Invoking Save Method to add Company Details");
        return companyService.saveCompany(company);
    }

//    @GetMapping("/{companyCode}")
//    public ResponseTemplateVO getCompanyWithStockDetails(@PathVariable("companyCode") String companyCode) {
//        return companyService.getCompanyWithStockDetails(companyCode);
//    }


    @GetMapping("/companyDetails/{companyCode}")
    public CompanyDetails getCompanyWithStockDetails(@PathVariable("companyCode") String companyCode) {
        log.info("Finding company Details");
        return companyService.findByCompanyCode(companyCode);
    }

    @RequestMapping(value = "/delete/{companyCode}", method = RequestMethod.DELETE)
    public String deleteByCompanyCode(@PathVariable String companyCode) {
        String message=companyService.deleteByCompanyCode(companyCode);
        log.info(message);
        return message;
    }
//
//    @GetMapping("/companyStockDetails/{companyCode}")
//    public ResponseTemplateVO findByCompanyCode(@PathVariable("companyCode") String companyCode) {
//        return companyService.findCompanyAndStockDetails(companyCode);
//    }
}

