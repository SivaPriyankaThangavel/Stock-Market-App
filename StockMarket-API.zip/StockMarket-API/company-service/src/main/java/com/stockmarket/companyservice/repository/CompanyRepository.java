package com.stockmarket.companyservice.repository;

import com.stockmarket.companyservice.entities.CompanyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyRepository extends JpaRepository<CompanyDetails, String> {
    CompanyDetails findByCompanyCode(String companyCode);

    void deleteByCompanyCode(String companyCode);
}
