package com.stockmarket.companyservice.service;

import com.stockmarket.companyservice.entities.CompanyDetails;
import com.stockmarket.companyservice.repository.CompanyRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private RestTemplate restTemplate;

    public CompanyDetails saveCompany(CompanyDetails company) {
        log.info("Details saved successfully for {} company", company.getCompanyName());
        return companyRepository.save(company);
    }

//    public ResponseTemplateVO getCompanyWithStockDetails(String companyCode) {
//        ResponseTemplateVO vo = new ResponseTemplateVO();
//        CompanyDetails company = companyRepository.findByCompanyCode(companyCode);
////        StockPriceDetails stock =
////                restTemplate.getForObject("http://localhost:9193/stocks/" + companyCode, StockPriceDetails.class);
////        vo.setCompany(company);
//        return vo;
//    }

    public String deleteByCompanyCode(String companyCode) {
        if (companyRepository.existsById(companyCode)) {
            log.info("Deleted company Details for {} company code ", companyCode);
            companyRepository.deleteById(companyCode);
        }
        restTemplate.delete("http://STOCK-SERVICE/stocks/delete/"+companyCode);
        return "Company and Stock Deleted Successfully";

    }

    public CompanyDetails findByCompanyCode(String companyCode) {
        return companyRepository.findByCompanyCode(companyCode);
    }

    /**
     * @param companyCode
     * @return
     */
//    public ResponseTemplateVO findCompanyAndStockDetails(String companyCode) {
//        ResponseTemplateVO vo = new ResponseTemplateVO();
//        CompanyDetails company = companyRepository.findByCompanyCode(companyCode);
////        List<StockPriceDetails> stockDetailList=new ArrayList<StockPriceDetails>();
//        StockDetailsList allStockDetails= restTemplate.getForObject(
//                "http://localhost:9193/stocks/stockInfo/" + companyCode,StockDetailsList.class);
//        vo.setCompany(company);
//        vo.setStock(allStockDetails);
//        return vo;
//    }
}

