import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StockModel } from '../models/stockModel';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-add-stock',
  templateUrl: './add-stock.component.html',
  styleUrls: ['./add-stock.component.css']
})
export class AddStockComponent implements OnInit {

  public stockForm!: FormGroup;
  companyCode = new FormControl();
  stockPrice = new FormControl();
  stock:StockModel= new StockModel();
  
  constructor(private formBuilder: FormBuilder, private stockService: StockService, private router: Router) { }

  ngOnInit(): void {
    this.initForm();
  }
  private initForm() {
    this.stockForm = this.formBuilder.group({
      companyCode: ['', [Validators.required]],
      price: ['', [Validators.required]],
    });
  }
  next() {
    this.stockForm.markAllAsTouched();
    let stockFormValues: StockModel = this.stockForm.getRawValue();
    console.log(stockFormValues.companyCode);
    console.log(stockFormValues.price);
    if( this.stockForm.valid){
    this.stockService.createStock(stockFormValues)
      .subscribe((v) =>{
      console.info(v);
      this.stockForm.reset();
      this.stock = new StockModel();
      this.router.navigate(['/company-stock-details']);
      });
    }

  }

}
