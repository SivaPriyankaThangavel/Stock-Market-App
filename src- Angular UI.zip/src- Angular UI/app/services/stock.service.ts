import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { stockServiceBasePath } from '../common/api-constants';

@Injectable({
  providedIn: 'root',
})
export class StockService {
  public baseUrl = stockServiceBasePath;
  createStock(stock: any) {
    console.log(stock);
    return this.httpClient.post(`${this.baseUrl}`, stock);
  }

  fetchDetailsByCompanyCode(companyCode: any): Observable<any> {
    console.log(companyCode);
    return this.httpClient.get(
      `${this.baseUrl}` + 'stockInfo/' + `${companyCode}`
    );
  }
  getStock(companyCode: any): Observable<any> {
    console.log(companyCode);
    return this.httpClient.get(
      `${this.baseUrl}`+ `${companyCode}`
    );
  }
  deleteByCompanyCode(companyCode: any): any {
    console.log(companyCode);
    return this.httpClient.delete(
      `${this.baseUrl}` + 'delete/' + `${companyCode}`,
      { responseType: 'text' }
    );
  }
  constructor(private httpClient: HttpClient) {}
}
