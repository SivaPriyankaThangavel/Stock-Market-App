import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { companyServiceBasePath } from '../common/api-constants';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  public baseUrl = companyServiceBasePath;
  createCompany(company: any) {
    console.log(company);
    return this.httpClient.post(`${this.baseUrl}`,company);
  }
  deleteByCompanyCode(companyCode: any): any {
    console.log(companyCode);
    return this.httpClient.delete(
      `${this.baseUrl}` + 'delete/' + `${companyCode}`,
      { responseType: 'text' }
    );
  }

  constructor(private httpClient: HttpClient) { }
}
