import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'stockmarket-ui';
  constructor(
    private router: Router
  ){}
  routeToCompany() {
    this.router.navigate(['/add-company']);
  }
  routeToStock() {
    this.router.navigate(['/add-stock']);
  }
  routeToFetchDetails() {
    this.router.navigate(['/company-stock-details']);
  }
  routeToHomePage() {
    this.router.navigate(['/home']);
  }
}
