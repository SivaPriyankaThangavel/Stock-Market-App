export const companyServiceBasePath = 'http://localhost:9192/companies/';
export const stockServiceBasePath = 'http://localhost:9193/stocks/';