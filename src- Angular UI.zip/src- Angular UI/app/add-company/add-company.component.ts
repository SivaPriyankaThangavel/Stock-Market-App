import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyModel } from '../models/companyModel';
import { CompanyService } from '../services/company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css'],
})
export class AddCompanyComponent implements OnInit {
  public companyForm!: FormGroup;
  companyCode = new FormControl();
  companyName = new FormControl();
  companyCEO = new FormControl();
  companyTurnOver = new FormControl();
  companyWebsite = new FormControl();
  stockExchange = new FormControl();
  company: CompanyModel = new CompanyModel();

  constructor(
    private formBuilder: FormBuilder,
    private companyService: CompanyService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initForm();
  }
  private initForm() {
    this.companyForm = this.formBuilder.group({
      companyCode: ['', [Validators.required]],
      companyName: ['', [Validators.required]],
      companyCEO: ['', [Validators.required]],
      companyTurnOver: ['', [Validators.required]],
      companyWebsite: ['', [Validators.required]],
      stockExchange: ['', [Validators.required]],
    });
  }
  next() {
    this.companyForm.markAllAsTouched();
    const companyFormValues: CompanyModel = this.companyForm.getRawValue();
    console.log(companyFormValues.companyName);
    if(this.companyForm.valid){
    this.companyService.createCompany(companyFormValues).subscribe((v) => {
      console.info(v);
      this.companyForm.reset();
      this.company = new CompanyModel();
      this.router.navigate(['/add-stock']);
    });
  }
}
}
