import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from '@angular/forms';
import { companyStockDetails } from '../models/companyStockDetails';
import { CompanyService } from '../services/company.service';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-company-stock-details',
  templateUrl: './company-stock-details.component.html',
  styleUrls: ['./company-stock-details.component.css'],
})
export class CompanyStockDetailsComponent implements OnInit {
  public detailsForm!: FormGroup;
  stockDetails: string = 'Search Your Stocks here!!';
  companyCode = new FormControl();
  companyStock: any;
  StockPriceDetailsArray: companyStockDetails[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private stockService: StockService,
    private companyService: CompanyService
  ) {}

  ngOnInit(): void {
    this.initForm();
  }
  private initForm() {
    this.detailsForm = this.formBuilder.group({
      companyCode: ['', [Validators.required]],
    });
  }

  submit() {
    this.StockPriceDetailsArray = [];
    this.detailsForm.markAllAsTouched();
    const stockFormValues = this.detailsForm.getRawValue();
    console.log(stockFormValues.companyCode);
    this.stockService
      .getStock(stockFormValues.companyCode)
      .subscribe((data) => {
        console.log('Stock Details', data);
        if (data !== null) {
          this.stockService
            .fetchDetailsByCompanyCode(stockFormValues.companyCode)
            .subscribe((data) => {
              this.companyStock = data;
              console.log('Company Stock', this.companyStock);
              const Stocks = this.companyStock?.stock;
              console.log(Stocks);
              if (Stocks && Stocks !== null) {
                Stocks.forEach((stock: { price: number }) => {
                  let companyStockDetails: companyStockDetails = {
                    company: {
                      companyCode: '',
                      companyName: '',
                      companyCEO: '',
                      companyTurnOver: '',
                      companyWebsite: '',
                      stockExchange: '',
                    },
                    stock: {
                      companyCode: '',
                      price: 0,
                    },
                  };
                  companyStockDetails.company.companyCode =
                    this.companyStock.company.companyCode;
                  companyStockDetails.company.companyName =
                    this.companyStock.company.companyName;
                  companyStockDetails.company.companyCEO =
                    this.companyStock.company.companyCEO;
                  companyStockDetails.company.companyWebsite =
                    this.companyStock.company.companyWebsite;
                  companyStockDetails.company.companyTurnOver =
                    this.companyStock.company.companyTurnOver;
                  companyStockDetails.company.stockExchange =
                    this.companyStock.company.stockExchange;
                  companyStockDetails.stock.price = stock.price;
                  this.StockPriceDetailsArray.push(companyStockDetails);
                });
              }
            });
        } else {
          this.StockPriceDetailsArray = [];
          this.stockDetails = 'No Records Found!!';
        }
      });
  }

  delete() {
    this.detailsForm.markAllAsTouched();
    const stockFormValues = this.detailsForm.getRawValue();
    this.stockService
      .getStock(stockFormValues.companyCode)
      .subscribe((data) => {
        console.log('Stock Details', data);
        if (data !== null) {
          this.companyService
            .deleteByCompanyCode(stockFormValues.companyCode)
            .subscribe((data: any) => {
              console.log(data);
              this.stockDetails = 'Stock Details deleted successfully!!';
              this.StockPriceDetailsArray = [];
            });
        } else {
          this.StockPriceDetailsArray = [];
          this.stockDetails = 'No Records Found!!';
        }
      });
  }
}
