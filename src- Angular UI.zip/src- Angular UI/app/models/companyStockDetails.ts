import { CompanyModel } from "./companyModel";
import { StockModel } from "./stockModel";


export class companyStockDetails {
    company!: CompanyModel;
    stock!: StockModel;
}