export class StockModel {
    companyCode: string ='';
    price: number = 0;
}