export class CompanyModel {
    companyCode: string ='';
    companyName: string ='';
    companyCEO: string ='';
    companyTurnOver: string ='';
    companyWebsite: string ='';
    stockExchange: string ='';
}