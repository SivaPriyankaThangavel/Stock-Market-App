import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCompanyComponent } from './add-company/add-company.component';
import { AddStockComponent } from './add-stock/add-stock.component';
import { CompanyStockDetailsComponent } from './company-stock-details/company-stock-details.component';
import { HomePageComponent } from './home-page/home-page.component';

const routes: Routes = [
  {
    path: 'add-company',
    component: AddCompanyComponent,
  },
  {
    path: 'add-stock',
    component: AddStockComponent,
  },
  {
    path: 'company-stock-details',
    component: CompanyStockDetailsComponent,
  },
  { path: 'home', component: HomePageComponent },
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
